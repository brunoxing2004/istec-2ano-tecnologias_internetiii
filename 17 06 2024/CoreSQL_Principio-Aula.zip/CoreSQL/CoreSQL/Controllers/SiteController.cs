﻿using CoreSQL.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CoreSQL.Controllers {
    public class SiteController : Controller {


        public IActionResult Contacto() {
            return View();
        }
    }
}
