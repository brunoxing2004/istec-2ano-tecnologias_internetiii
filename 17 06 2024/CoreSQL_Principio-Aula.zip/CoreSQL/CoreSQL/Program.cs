using CoreSQL.Models;
internal class Program {

    //public static string conexaoGlobal = "server=EDP-JR-10H2\\SQL14; database=GestaoDocumental; uid=IUser; pwd=IUser; TrustServerCertificate=False; Encrypt=False";

    public static string Conector = "";
    public static string SmtpIP = "";
    
    private static void Main(string[] args) {
        var builder = WebApplication.CreateBuilder(args);
        //<Implementa��o do servi�o de Sess�es>
        builder.Services.AddSession(s  => s.IdleTimeout  = TimeSpan.FromMinutes(20));
        //</Implementa��o do servi�o de Sess�es>
        builder.Services.AddMvc();

        var config = builder.Configuration.GetSection("Configuracao").Get<Configuracao>();
        Conector = config.Conexao;
        SmtpIP = config.SmtpIP;

        var app = builder.Build();
        app.UseStaticFiles();
        app.UseRouting();
        //<Implementa��o de Sess�es>
        app.UseSession();
        //<Implementa��o de Sess�es>

        //app.MapGet("/", () => "Hello World!");
        app.MapControllerRoute(
           name: "default",
           pattern: "{controller=Documento}/{action=Listar}/{op?}"
       );
        app.Run();
    }
}