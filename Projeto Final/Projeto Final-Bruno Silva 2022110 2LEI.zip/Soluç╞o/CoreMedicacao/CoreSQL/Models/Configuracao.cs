﻿namespace CoreSQL.Models
{
    public class Configuracao
    {
        public string Conexao { get; }
        

    }
}
