﻿namespace CoreSQL.Models
{
    public class HelperBase
    {
        public readonly string ConectorHerdado = Program.Conector;
    }
}
