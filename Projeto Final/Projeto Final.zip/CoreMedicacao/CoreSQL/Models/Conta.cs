﻿namespace CoreSQL.Models
{
    public class Conta
    {
        public string Guid { get; set; }
        public string Utilizador { get; set; }
        public string Password { get; set; }
        public string NivelAcesso { get; set; }

    }
}
