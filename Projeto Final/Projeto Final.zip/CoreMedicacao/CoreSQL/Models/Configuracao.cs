﻿namespace CoreSQL.Models
{
    public class Configuracao
    {
        public string Conexao { get; }
        public string SmtpIP { get; set; }
        public string UseTLS { get; set; }

    }
}
