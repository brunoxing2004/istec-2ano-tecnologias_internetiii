﻿namespace DemoObjetos.Models
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string Nif { get; set; }

        public Cliente()
        {
            Nome = "";
            Nif = "";
        }
        
    }
}
